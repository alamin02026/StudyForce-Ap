# Study Force: GitHub দিয়ে APK বানানোর নির্দেশ

এই প্যাকেজে ২টা জিনিস আছে:
1. `StudyForce_all_code.txt`  → অ্যাপের পুরো কোড (এক ফাইলে)
2. `.github/workflows/build.yml` → GitHub-কে বলে দেয় কীভাবে APK বানাতে হবে

## ধাপ ১: GitHub-এ রিপোজিটরি বানাও
1. github.com-এ ফ্রি অ্যাকাউন্ট খোলো, ইমেইল ভেরিফাই করো।
2. উপরে ডানে **+** > **New repository**।
3. নাম: `StudyForce`, **Private** বেছে **Create repository** চাপো।

## ধাপ ২ (কম্পিউটারে, সবচেয়ে সহজ): সব ফাইল একসাথে আপলোড
1. এই জিপ extract করো।
2. রিপোজিটরির পাতায় **uploading an existing file** চাপো।
3. extract করা ফোল্ডারের ভেতরের সব কিছু টেনে ছাড়ো (`StudyForce_all_code.txt` আর `.github` ফোল্ডার)।
   `.github` লুকানো ফোল্ডার, Windows-এ File Explorer > View > Hidden items চালু করো।
4. **Commit changes** চাপো।

## ধাপ ২ (ফোনে): দুটো ফাইল আলাদা করে দাও
1. ব্রাউজারে **Desktop site** চালু করো।
2. **Add file > Upload files** চেপে শুধু `StudyForce_all_code.txt` দাও, Commit করো।
3. **Add file > Create new file** চাপো।
4. নামের ঘরে হুবহু লেখো: `.github/workflows/build.yml`
   (লেখার সময় `/` দিলে ফোল্ডার নিজে তৈরি হয়)
5. `build.yml` ফাইলের সব লেখা কপি করে বড় ঘরে বসাও। **Commit changes**।
   লেখার সাজানো (ফাঁকা জায়গা) যেন না বদলায়, সবটা একসাথে কপি করবে।

## ধাপ ৩: APK ডাউনলোড
1. রিপোজিটরির **Actions** ট্যাবে যাও। "Build APK" নিজে চলবে (৫-১০ মিনিট)।
2. সবুজ টিক এলে ওই কাজে চাপো।
3. একদম নিচে **Artifacts** > **StudyForce-APK** ডাউনলোড করো।
4. জিপ extract করলে `app-debug.apk` পাবে। ফোনে ইনস্টল করো।

## ফেল করলে (লাল ✗)
- কাজটায় চাপো, যে ধাপে লাল ✗ আছে সেটা খোলো।
- সেই ধাপের শেষের লেখাগুলোর স্ক্রিনশট বা কপি Claude-কে পাঠাও।
- সাধারণ কারণ:
  - **ERROR: no code .txt file**: `.txt` ফাইলটা রিপোজিটরির প্রথম পাতায় (কোনো ফোল্ডারের ভেতরে নয়) আপলোড হয়নি।
  - **Invalid workflow file**: `build.yml`-এর লেখা কপির সময় এলোমেলো হয়েছে, বা ফাইলের নাম ঠিক নেই।
  - Build debug APK ধাপে লাল: কোডে এরর, আমাকে পাঠালে ঠিক করে দেব।

## ইনস্টলের পর (ফোনে)
অ্যাপ খুলে "Finish setup"-এর ৪টা Enable চাপো।
Android 13+: Settings > Apps > Study Force > তিন ডট > **Allow restricted settings**।
